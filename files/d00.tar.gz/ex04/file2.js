function cat()
{
	whale();
}

cat()
